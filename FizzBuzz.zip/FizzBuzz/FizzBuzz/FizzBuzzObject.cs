﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FizzBuzz {
    public class FizzBuzzObject {
        public const string Fizz = "Fizz";
        public const string Buzz = "Buzz";
        public const string FizzBuzz = "FizzBuzz";

        public List<string> GetFizzBuzzArray(int number) {
            CheckIfNumberIsZero(number);
            var result = new List<string>();
            for (int number_to_check = 1; number_to_check <= number; number_to_check++) {

                if (IsMultipleOfThree(number_to_check) && IsMultipleOfFive(number_to_check)) {
                    result.Add(FizzBuzz);

                } else if (IsMultipleOfThree(number_to_check)) {
                    result.Add(Fizz);

                } else if (IsMultipleOfFive(number_to_check)) {
                    result.Add(Buzz);

                } else {
                    result.Add(Convert.ToString(number_to_check));

                }
            }
            return result;

        }

        public void CheckIfNumberIsZero(int number) {
            if (number <= 0) {
                throw new ArgumentOutOfRangeException("n", "The number should be greather than zero");
            }
        }


        public bool IsMultipleOfThree(int number_to_check) {
            if (number_to_check % 3 == 0) {
                return true;
            }
            return false;
        }
        public bool IsMultipleOfFive(int number_to_check) {
            if (number_to_check % 5 == 0) {
                return true;
            }
            return false;
        }
    }
}
