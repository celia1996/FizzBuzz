﻿using System;
using System.Collections.Generic;
namespace FizzBuzz {
    class FizzBuzz {
        static void Main(string[] args) {
            Console.Write("Type any number to write the FizzBuzz array:  ");
            int number = Int32.Parse(Console.ReadLine());
            var fizzbuzz = new FizzBuzzObject();
            var fizzbuzzarray = new List<string>();
            fizzbuzzarray = fizzbuzz.GetFizzBuzzArray(number);
            fizzbuzzarray.ForEach(Console.WriteLine);

        }

    }
}

