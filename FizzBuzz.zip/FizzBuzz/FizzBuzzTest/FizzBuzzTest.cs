using System;
using NUnit.Framework;
using FizzBuzz;

namespace FizzBuzzTest {
    [TestFixture]
    public class FizzBuzzTests {
        [Test]
        public void FizzBuzzTest_TheNumberIsZero() {
            int input = 0;
            var fizzbuzz = new FizzBuzzObject();
            Assert.Throws<ArgumentOutOfRangeException>(() => fizzbuzz.GetFizzBuzzArray(input));
        }

        [Test]
        public void FizzBuzzTest_TheNumberIsOne() {
            int input = 1;
            string[] expected = { "1" };
            var fizzbuzz = new FizzBuzzObject();
            var actual = fizzbuzz.GetFizzBuzzArray(input);

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void FizzBuzzTest_TheNumberIsThree() {
            int input = 3;
            string[] expected = { "1", "2", "Fizz" };

            var fizzbuzz = new FizzBuzzObject();
            var actual = fizzbuzz.GetFizzBuzzArray(input);

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void FizzBuzzTest_TheNumberIsFive() {
            int input = 5;
            string[] expected = { "1", "2", "Fizz", "4", "Buzz" };

            var fizzbuzz = new FizzBuzzObject();
            var actual = fizzbuzz.GetFizzBuzzArray(input);

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void FizzBuzzTest_TheNumberIsFiveteen() {
            int input = 15;
            string[] expected = { "1", "2", "Fizz", "4", "Buzz", "Fizz", "7", "8", "Fizz", "Buzz", "11", "Fizz", "13", "14", "FizzBuzz" };

            var fizzbuzz = new FizzBuzzObject();
            var actual = fizzbuzz.GetFizzBuzzArray(input);
            Assert.AreEqual(expected, actual);
        }
    }
}

